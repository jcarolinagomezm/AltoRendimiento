extern void Sample_Init (int argc, char *argv[]);
extern void Sample_Start(int THR);
void Sample_Stop (int THR);
int  Sample_PAR_install (void);
void Sample_End  (void);
