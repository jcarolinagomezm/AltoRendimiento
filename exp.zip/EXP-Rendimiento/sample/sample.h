extern void Sample_Init (int argc, char *argv[]);
extern void Sample_Start(int THR);
extern void Sample_Stop (int THR);
extern int  Sample_PAR_install (void);
extern void Sample_End  (void);
